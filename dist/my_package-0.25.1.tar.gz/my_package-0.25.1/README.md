# Fama-French industry SIC code mapping

Python code to read the industry definitions files from Ken French's  [Data Library](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html) and return a dictionary that maps from SIC code to Fama-French industry code.